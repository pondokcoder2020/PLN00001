<script type="text/javascript">
	$(document).ready(function(){
		function al_alert(){
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'AAAAAAAAA',
            })
        }
	})
</script>